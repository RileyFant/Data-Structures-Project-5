#include <iostream>
#include <math.h>
#include <time.h>
#include <Windows.h>
#include <fstream>
#include "Helper.h"

using namespace std;

void stringBubbleSort(char** array, int count) {
	for (int i = 0; i < count - 1; i++) {
		for (int j = 0; j < count - 1; j++) {
			if (myStrCmp(array[j], array[j + 1]) > 0) {
				//swapStrings(array[j], array[j + 1]);
				char* temp = array[j]; // ZY
				char* jp1 = array[j + 1]; // H
				array[j] = array[j + 1];
				array[j + 1] = temp;
			}
		}
	}
}

void stringRadixSort(char** array, int length, int count) {
	//no
}


int main() {
	//make the list of characters to choose from
	char lettersAndNumbers[36];
	for (int i = 0; i < 10; i++) {
		lettersAndNumbers[i] = 48 + i;
	}
	for (int i = 10; i < 36; i++) {
		lettersAndNumbers[i] = 65 - 10 + i;
	}
	for (int i = 0; i < 36; i++) {
		cout << lettersAndNumbers[i];
	}
	cout << endl;

	int count = 10000;
	int length = 10;
	LARGE_INTEGER start, stop;
	ofstream radixResults("radixResults.txt");
	ofstream bubbleResults("bubbleResults.txt");
	while (count <= 50000) {
		for (int i = 0; i <= 10; i++) {
			//sort with bubble
			char** A = makeRandomStrings(lettersAndNumbers, count, length);
			char** B = copyStrings(A, count, length);

			QueryPerformanceCounter(&start); //start the timer
			stringBubbleSort(A, count);
			QueryPerformanceCounter(&stop); //stop the timer

			//print out how long it took
			cout << "\nTicks taken to sort the " << i+1 << "th " << count << " elements: with bubble " << stop.QuadPart - start.QuadPart << endl;
			bubbleResults << count << ',' << stop.QuadPart - start.QuadPart << '\n';

			//sort with radix
			QueryPerformanceCounter(&start); //start the timer
			stringRadixSort(B, count);
			QueryPerformanceCounter(&stop); //stop the timer

			//print out how long it took
			cout << "\nTicks taken to sort the " << i + 1 << "th " << count << " elements with radix: " << stop.QuadPart - start.QuadPart << endl;
			radixResults << count << ',' << stop.QuadPart - start.QuadPart << '\n';


			//cout << "\n\nsorted (first 10): " << endl;
			/*for (int i = 0; i < 1000; i++) {
				int j = 0;
				while ((A[i][j] > 47 && A[i][j] < 58) || (A[i][j]>64 && A[i][j] < 91)) {
					cout << A[i][j];
					j++;
				}
				cout << endl;
			}*/
		}
		count += 5000;
	}
	bubbleResults.close();
	radixResults.close();
	return 0;

}