/*cout << "\nunsorted (first 10): " << endl;
for (int i = 0; i < 10; i++) {
cout << A[i] << endl;
}*/

/*cout << "\n\nsorted (first 10): " << endl;
for (int i = 0; i < 10; i++) {
int j = 0;
while ((A[i][j] > 47 && A[i][j] < 58) || (A[i][j]>64 && A[i][j] < 91)) {
cout << A[i][j];
j++;
}
cout << endl;
}*/


#include <iostream>
#include <math.h>
#include <time.h>
#include <Windows.h>
#include <fstream>
#include <queue>
using namespace std;

char** makeRandomStrings(char* source, int count, int length){
	srand(time(NULL));
	char** A = new char*[count];
	for (int i = 0; i < count; i++) {
		A[i] = new char[length + 1];
	}
	for (int i = 0; i < count; i++) {
		int r = rand() % 10 + 1;
		for (int j = 0; j < r; j++) {
			A[i][j] = source[rand() % 36];
		}
		for (int j = r; j < 10; j++) {
			A[i][j] = '\0';
		}
		
	}
	return A;
}

char** copyStrings(char** strings, int count, int length) {
	char** copy = new char*[count];
	for (int i = 0; i < count; i++) {
		copy[i] = new char[length + 1];
	}
	for (int i = 0; i < count; i++) {
		for (int j = 0; j < length; j++) {
			copy[i][j] = strings[i][j];
		}
	}
	return copy;
}

void stringRadixSort(char** strings, int count) {
	queue<char*> theQ[91];
	for (int index = 9; index >= 0; index--)
	{
		for (int i = 0; i < count; i++)
		{
			theQ[strings[i][index]].push(strings[i]);
		}
		int index = 0;
		for (int q = 0; q < 91; q++)
		{
			while (!theQ[q].empty())
			{
				strings[index] = theQ[q].front();
				theQ[q].pop();
				index++;
			}//while the queue is not empty
		}//for q
	}
}

int myStrCmp(const char *s1, const char *s2) {
	const unsigned char *p1 = (const unsigned char *)s1;
	const unsigned char *p2 = (const unsigned char *)s2;

	while (*p1 != '\0') {
		if (*p2 == '\0') return  1;
		if (*p2 > *p1)   return -1;
		if (*p1 > *p2)   return  1;

		p1++;
		p2++;
	}

	if (*p2 != '\0') return -1;

	return 0;
}


//im not actually using this now
//i just switch the pointer instead
void swapStrings(char* one, char* two) {

	char* temp = new char[10];
	for (int i = 0; i<10; i++) {
		temp[i] = one[i];
	}
	for (int i = 0; i<10; i++)  {
		one[i] = two[i];
	}
	for (int i = 0; i<10; i++) {
		two[i] = temp[i];
	}
	delete[] temp;
}